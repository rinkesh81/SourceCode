﻿using Microsoft.Azure.Documents;
using Microsoft.Azure.Documents.Client;
using System;
using System.Configuration;
using System.IO;
using System.Threading.Tasks;

namespace AzureCosmosDbStoredProcedure
{
    class Program
    {
        static void Main(string[] args)
        {
            Task.Run(async () =>
            {
                var endpoint = ConfigurationManager.AppSettings["DocDbEndpoint"];
                var masterKey = ConfigurationManager.AppSettings["DocDbMasterKey"];
                using (var client = new DocumentClient(new Uri(endpoint), masterKey))
                {
                    Console.WriteLine("\r\n>>>>>>>>>>>>>>>> Creating Database <<<<<<<<<<<<<<<<<<<");
                    // Create new database Object
                    //Id defines name of the database
                    var databaseDefinition = new Database { Id = "testDb" };
                    var database = await client.CreateDatabaseIfNotExistsAsync(databaseDefinition);
                    Console.WriteLine("Database testDb created successfully");

                    //Create new database collection
                    Console.WriteLine("\r\n>>>>>>>>>>>>>>>> Creating Collection <<<<<<<<<<<<<<<<<<<");
                    var collectionDefinition = new DocumentCollection { Id = "testDocumentCollection" };
                    var collection = await client.CreateDocumentCollectionIfNotExistsAsync(UriFactory.CreateDatabaseUri("testDb"),
                        collectionDefinition);
                    Console.WriteLine("Collection testDocumentCollection created successfully");

                    var sprocBody = File.ReadAllText(@"..\..\StoredProcedures\spHelloWorld.js");
                    var spDefinition = new StoredProcedure
                    {
                        Id = "spHelloWorld",
                        Body = sprocBody
                    };

                    //Create Store Procedure
                    StoredProcedure sproc = await client.CreateStoredProcedureAsync
                        (UriFactory.CreateDocumentCollectionUri("testDb", "testDocumentCollection"), spDefinition);
                    Console.WriteLine($"\r\nCreated Store procedure Id:{sproc.Id} ");

                    //Execute Store Procedure
                    var result = await client.ExecuteStoredProcedureAsync<string>
                        (UriFactory.CreateStoredProcedureUri("testDb", "testDocumentCollection", "spHelloWorld"));
                    Console.WriteLine($"Executed Store Procedure: response:{result.Response}");

                    //Delete Store Procedure
                    await client.DeleteStoredProcedureAsync
                        (UriFactory.CreateStoredProcedureUri("testDb", "testDocumentCollection", "spHelloWorld"));
                    Console.WriteLine("Stored Procedure Deleted Successfully");

                    Console.ReadKey();
                }
            }).Wait();
        }
    }
}
